export const PORT = process.env.PORT || 5555;

export const mongoDBURL =
  'mongodb+srv://shariquerahman24:AQ8vX1hj93U1yW8C@cluster.duw7g.mongodb.net/?retryWrites=true&w=majority&appName=Cluster';